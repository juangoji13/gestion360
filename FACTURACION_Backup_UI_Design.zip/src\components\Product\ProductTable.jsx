import React from 'react'
import { Pencil, Trash2, Package, MoreVertical, Edit3, Trash } from 'lucide-react'
import { formatCurrency } from '../../utils/formatters'

export default function ProductTable({ products, onOpenEdit, onDelete }) {
    return (
        <div className="prod-table-wrapper">
            {/* VISTA ESCRITORIO (TABLA) */}
            <table className="prod-table desktop-only">
                <thead>
                    <tr>
                        <th style={{ width: '120px' }}>SKU</th>
                        <th>Nombre del Producto / Desc</th>
                        <th style={{ width: '120px' }}>Unidad</th>
                        <th style={{ width: '150px' }}>Estado</th>
                        <th style={{ width: '140px', textAlign: 'right' }}>P. Base (Compra)</th>
                        <th style={{ width: '140px', textAlign: 'right' }}>P. Venta</th>
                        <th style={{ width: '120px', textAlign: 'center' }}>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    {products.length === 0 ? (
                        <tr>
                            <td colSpan="7" style={{ textAlign: 'center', padding: '3rem' }}>
                                <div style={{ color: '#94a3b8', marginBottom: '0.5rem' }}>
                                    <svg style={{ margin: '0 auto', width: '40px', height: '40px' }} fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="1.5">
                                        <path strokeLinecap="round" strokeLinejoin="round" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" />
                                    </svg>
                                </div>
                                <p style={{ color: '#475569', fontWeight: 500 }}>
                                    No se encontraron resultados
                                </p>
                            </td>
                        </tr>
                    ) : (
                        products.map((product) => (
                            <tr key={product.id}>
                                <td className="prod-sku">{product.sku || '-'}</td>
                                <td>
                                    <div className="prod-info">
                                        <div className="prod-img-placeholder">
                                            <Package size={20} color="#64748b" />
                                        </div>
                                        <div>
                                            <div className="prod-name">{product.name}</div>
                                            <div style={{ fontSize: '0.75rem', color: '#64748b', maxWidth: '250px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                                                {product.description || 'Sin descripción'}
                                            </div>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <span className="prod-cat-badge">{product.unit || 'und'}</span>
                                </td>
                                <td>
                                    {product.stock <= 0 ? (
                                        <div className="prod-stock-badge">
                                            <div className="prod-stock-dot" style={{ backgroundColor: '#ef4444' }}></div>
                                            <span className="prod-stock-text" style={{ color: '#ef4444', fontWeight: 600 }}>Sin stock</span>
                                        </div>
                                    ) : product.stock < 5 ? (
                                        <div className="prod-stock-badge">
                                            <div className="prod-stock-dot" style={{ backgroundColor: '#f59e0b' }}></div>
                                            <span className="prod-stock-text" style={{ color: '#f59e0b', fontWeight: 600 }}>Bajo Stock ({product.stock})</span>
                                        </div>
                                    ) : (
                                        <div className="prod-stock-badge">
                                            <div className="prod-stock-dot" style={{ backgroundColor: '#10b981' }}></div>
                                            <span className="prod-stock-text">Disponible ({product.stock})</span>
                                        </div>
                                    )}
                                </td>
                                <td className="prod-price" style={{ textAlign: 'right', color: '#64748b' }}>
                                    {formatCurrency(product.base_price)}
                                </td>
                                <td className="prod-price" style={{ textAlign: 'right', fontWeight: 700 }}>
                                    {formatCurrency(product.sale_price)}
                                </td>
                                <td>
                                    <div style={{ display: 'flex', gap: '8px', justifyContent: 'center' }}>
                                        <button
                                            onClick={() => onOpenEdit(product)}
                                            style={{ background: 'transparent', border: 'none', color: '#64748b', cursor: 'pointer', padding: '4px' }}
                                            title="Editar"
                                        >
                                            <Pencil size={18} />
                                        </button>
                                        <button
                                            onClick={() => onDelete(product)}
                                            style={{ background: 'transparent', border: 'none', color: '#ef4444', cursor: 'pointer', padding: '4px' }}
                                            title="Eliminar"
                                        >
                                            <Trash2 size={18} />
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        ))
                    )}
                </tbody>
            </table>

            {/* VISTA MÓVIL (TARJETAS) */}
            <div className="prod-mobile-list mobile-only">
                {products.length === 0 ? (
                    <div className="prod-mobile-empty">
                        <Package size={40} color="#cbd5e1" />
                        <p>No se encontraron productos</p>
                    </div>
                ) : (
                    products.map((product) => (
                        <div key={product.id} className="prod-mobile-card">
                            <div className="prod-mobile-card-header">
                                <div className="prod-mobile-card-title-group">
                                    <span className="prod-mobile-sku">SKU: {product.sku || 'N/A'}</span>
                                    <h3 className="prod-mobile-name">{product.name}</h3>
                                </div>
                                <span className={`prod-mobile-status-badge ${product.stock <= 0 ? 'out' : product.stock < 5 ? 'low' : 'ok'}`}>
                                    {product.stock <= 0 ? 'Sin Stock' : product.stock < 5 ? 'Bajo Stock' : 'Disponible'}
                                </span>
                            </div>

                            <div className="prod-mobile-grid">
                                <div className="prod-mobile-grid-item">
                                    <span className="prod-mobile-grid-label">Unidad</span>
                                    <span className="prod-mobile-grid-value">{product.unit || 'und'}</span>
                                </div>
                                <div className="prod-mobile-grid-item">
                                    <span className="prod-mobile-grid-label">P. Base</span>
                                    <span className="prod-mobile-grid-value">{formatCurrency(product.base_price)}</span>
                                </div>
                                <div className="prod-mobile-grid-item">
                                    <span className="prod-mobile-grid-label">P. Venta</span>
                                    <span className="prod-mobile-grid-value highlight">{formatCurrency(product.sale_price)}</span>
                                </div>
                            </div>

                            <div className="prod-mobile-actions">
                                <button className="prod-mobile-btn-edit" onClick={() => onOpenEdit(product)}>
                                    <Edit3 size={16} />
                                    <span>Editar</span>
                                </button>
                                <button className="prod-mobile-btn-delete" onClick={() => onDelete(product)}>
                                    <Trash size={16} />
                                </button>
                            </div>
                        </div>
                    ))
                )}
            </div>
        </div>
    )
}
