import { formatCurrency } from '../../utils/formatters'

export default function AdminStatsCards({ stats }) {
    if (!stats) return null

    return (
        <>
            <div className="admin-stats-grid">
                <div className="admin-stat-card admin-stat-blue">
                    <div className="admin-stat-icon">🏢</div>
                    <div className="admin-stat-value">{stats.total_businesses}</div>
                    <div className="admin-stat-label">Negocios Registrados</div>
                </div>
                <div className="admin-stat-card admin-stat-green">
                    <div className="admin-stat-icon">💰</div>
                    <div className="admin-stat-value">{formatCurrency(stats.total_revenue)}</div>
                    <div className="admin-stat-label">Ingresos Totales (Pagado)</div>
                </div>
                <div className="admin-stat-card admin-stat-amber">
                    <div className="admin-stat-icon">⏳</div>
                    <div className="admin-stat-value">{formatCurrency(stats.total_pending)}</div>
                    <div className="admin-stat-label">Facturación Pendiente</div>
                </div>
                <div className="admin-stat-card admin-stat-purple">
                    <div className="admin-stat-icon">🧾</div>
                    <div className="admin-stat-value">{stats.total_invoices}</div>
                    <div className="admin-stat-label">Facturas Totales</div>
                </div>
            </div>

            <div className="admin-row">
                <div className="admin-stat-card admin-stat-mini">
                    <span>👥</span>
                    <div>
                        <div className="admin-stat-value" style={{ fontSize: '1.5rem' }}>{stats.total_clients}</div>
                        <div className="admin-stat-label">Clientes</div>
                    </div>
                </div>
                <div className="admin-stat-card admin-stat-mini">
                    <span>📦</span>
                    <div>
                        <div className="admin-stat-value" style={{ fontSize: '1.5rem' }}>{stats.total_products}</div>
                        <div className="admin-stat-label">Productos</div>
                    </div>
                </div>
                <div className="admin-stat-card admin-stat-mini">
                    <span>✅</span>
                    <div>
                        <div className="admin-stat-value" style={{ fontSize: '1.5rem' }}>{stats.invoices_paid}</div>
                        <div className="admin-stat-label">Pagadas</div>
                    </div>
                </div>
                <div className="admin-stat-card admin-stat-mini">
                    <span>🕐</span>
                    <div>
                        <div className="admin-stat-value" style={{ fontSize: '1.5rem' }}>{stats.invoices_pending}</div>
                        <div className="admin-stat-label">Pendientes</div>
                    </div>
                </div>
                <div className="admin-stat-card admin-stat-mini">
                    <span>⚠️</span>
                    <div>
                        <div className="admin-stat-value" style={{ fontSize: '1.5rem' }}>{stats.invoices_overdue}</div>
                        <div className="admin-stat-label">Vencidas</div>
                    </div>
                </div>
            </div>
        </>
    )
}
