import React from 'react'
import { formatCurrency } from '../../utils/formatters'

export default function DashboardStatsCards({ stats, clientCount }) {
    const cards = [
        {
            label: `Ventas (${stats.rangeLabel})`,
            value: formatCurrency(stats.totalRevenue),
            color: '#10b981'
        },
        {
            label: `Ganancia Neta (${stats.rangeLabel})`,
            value: formatCurrency(stats.netProfit),
            color: '#6366f1',
            valueColor: '#10b981'
        },
        {
            label: 'Comprobantes',
            value: stats.totalInvoices,
            color: '#3b82f6'
        },
        {
            label: 'Clientes',
            value: clientCount,
            color: '#f59e0b'
        },
    ]

    return (
        <div className="dash-stats-grid">
            {cards.map((card, i) => (
                <div key={i} className="dash-stat-card">
                    <div className="dash-stat-stripe" style={{ backgroundColor: card.color }}></div>
                    <div className="dash-stat-content">
                        <div className="dash-stat-label">{card.label}</div>
                        <div className="dash-stat-value" style={card.valueColor ? { color: card.valueColor } : {}}>
                            {card.value}
                        </div>
                    </div>
                </div>
            ))}
        </div>
    )
}
