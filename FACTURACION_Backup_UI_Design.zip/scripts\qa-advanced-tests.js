// scripts/qa-advanced-tests.js
import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Cargar .env desde la raíz
dotenv.config({ path: path.resolve(__dirname, '../.env') });

const supabaseUrl = process.env.VITE_SUPABASE_URL;
const supabaseKey = process.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseKey) {
    console.error("Faltan variables de entorno");
    process.exit(1);
}

const supabase = createClient(supabaseUrl, supabaseKey);

const TEST_EMAIL = 'cuentadeprueba@gmail.com';
const TEST_PASSWORD = 'Juanthek13';

async function runTests() {
    console.log("🚀 Iniciando Pruebas Senior QA Nivel 2...\n");

    // 1. LOGIN
    console.log("🔑 Autenticando con cuenta de prueba...");
    const { data: authData, error: authError } = await supabase.auth.signInWithPassword({
        email: TEST_EMAIL,
        password: TEST_PASSWORD,
    });

    if (authError) {
        console.error("❌ Error de Auth:", authError.message);
        return;
    }
    console.log("✅ Autenticado exitosamente.\n");

    // 2. OBTENER CONTEXTO
    const { data: businesses } = await supabase.from('businesses').select('*').limit(1);
    if (!businesses || businesses.length === 0) {
        console.error("❌ No hay negocios para hacer la prueba.");
        return;
    }
    const businessId = businesses[0].id;

    // Obtener un cliente de prueba
    const { data: clients } = await supabase.from('clients').select('id').eq('business_id', businessId).limit(1);
    if (!clients || clients.length === 0) {
        console.error("❌ Se requiere al menos 1 cliente en DB.");
        return;
    }
    const clientId = clients[0].id;

    // Obtener un producto de prueba
    const { data: products } = await supabase.from('products').select('*').eq('business_id', businessId).limit(1);
    if (!products || products.length === 0) {
        console.error("❌ Se requiere al menos 1 producto en DB.");
        return;
    }
    const productId = products[0].id;

    // === START TESTS ===

    console.log("🔬 PRUEBA 1: Concurrencia y Colisión de Números (El ataque del 'Doble Click')");
    console.log("   Lanzando 5 peticiones RPC simultáneas e idénticas...");

    const makeInvoiceRequest = () => {
        return supabase.rpc('create_invoice_final', {
            p_invoice: {
                business_id: businessId,
                client_id: clientId,
                date: new Date().toISOString(),
                due_date: new Date().toISOString(),
                status: 'pending',
                notes: 'Prueba de Concurrencia QA'
            },
            p_items: [
                {
                    product_id: productId,
                    description: products[0].name,
                    quantity: 1,
                    unit_price: 100,
                    purchase_price: 50
                }
            ]
        });
    };

    const startTime = Date.now();
    const promises = [
        makeInvoiceRequest(),
        makeInvoiceRequest(),
        makeInvoiceRequest(),
        makeInvoiceRequest(),
        makeInvoiceRequest()
    ];

    const results = await Promise.all(promises);
    const endTime = Date.now();

    const invoiceNumbers = new Set();
    const invoiceIds = [];
    let collisionDetected = false;
    let errors = 0;

    results.forEach(res => {
        if (res.error) {
            errors++;
        } else if (res.data) {
            invoiceIds.push(res.data.id);
            if (invoiceNumbers.has(res.data.invoice_number)) {
                collisionDetected = true;
            }
            invoiceNumbers.add(res.data.invoice_number);
        }
    });

    console.log(`   Resultado: Se generaron ${invoiceNumbers.size} facturas exitosamente en ${endTime - startTime}ms. Fallidos: ${errors}`);
    if (collisionDetected) {
        console.error("   ❌ FALLO: Hubo colisión de números! Dos facturas tienen el mismo número.");
    } else {
        console.log("   ✅ ÉXITO: Los números son secuenciales y únicos (Bloqueo transaccional efectivo).");
        console.log("      Números generados:", Array.from(invoiceNumbers).join(', '));
    }
    console.log("");


    console.log("🔬 PRUEBA 2: Integridad Referencial (Huérfanos / Borrado Restrictivo)");
    console.log("   Intentando borrar el producto usado en las pruebas recién creadas...");

    const { error: deleteError } = await supabase.from('products').delete().eq('id', productId);

    if (deleteError) {
        console.log(`   ✅ ÉXITO: Sistema rechazó borrado (${deleteError.code} - ${deleteError.message}). El producto protege la factura.`);
    } else {
        console.error("   ❌ FALLO: El sistema permitió borrar un producto que pertenece a una factura. ¡Peligro de huérfanos!");
        // Reatañar el daño
    }
    console.log("");

    console.log("🔬 PRUEBA 3: Estrés de Carga de Lectura (Latencia y Paginación)");
    console.log("   Simulando peticiones masivas al dashboard...");

    const readStartTime = Date.now();
    const readPromises = Array.from({ length: 20 }, () =>
        supabase.rpc('get_dashboard_stats_v2', {
            p_business_id: businessId,
            p_start_date: '2020-01-01T00:00:00Z',
            p_end_date: new Date().toISOString()
        })
    );

    await Promise.all(readPromises);
    const readEndTime = Date.now();
    console.log(`   ✅ ÉXITO: 20 peticiones pesadas al dashboard respondidas en ${readEndTime - readStartTime}ms (Promedio: ${((readEndTime - readStartTime) / 20).toFixed(2)}ms por petición).`);

    console.log("\n🧹 Limpiando los datos de prueba masivos...");
    for (const id of invoiceIds) {
        await supabase.from('invoices').delete().eq('id', id);
    }
    console.log("🧹 Limpieza completada.");

    console.log("\n✅ BATERÍA DE PRUEBAS FINALIZADA.");
}

runTests();
