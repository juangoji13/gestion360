import React from 'react'
import { CircleDollarSign, TrendingUp, Sparkles } from 'lucide-react'
import { formatCurrency } from '../../utils/formatters'

export default function ProductStatsWidget({ metrics, topProducts }) {
    const { totalInvestment, totalSaleValue, totalMargin, marginPct } = metrics

    return (
        <aside className="prod-aside">
            {/* Resumen Grid: 1 col en PC, 2 cols en móvil (inversión full width) */}
            <div className="prod-metrics-grid">
                {/* Widget: Inversión */}
                <div className="prod-stats-card main-metric">
                    <div className="prod-stats-bg-icon">
                        <svg fill="currentColor" viewBox="0 0 24 24"><path d="M21 18v1a2 2 0 01-2 2H5a2 2 0 01-2-2V5a2 2 0 012-2h14a2 2 0 012 2v1h-9a2 2 0 00-2 2v8a2 2 0 002 2h9zm-9-2h10V8H12v8zm4-2.5a1.5 1.5 0 110-3 1.5 1.5 0 010 3z" /></svg>
                    </div>
                    <h3 className="prod-stats-label"><CircleDollarSign size={14} /> Inversión Inventario</h3>
                    <div className="prod-stats-value">{formatCurrency(totalInvestment)}</div>
                </div>

                {/* Venta Total */}
                <div className="prod-mini-card blue">
                    <div className="prod-mini-label"><TrendingUp size={12} /> P. Venta</div>
                    <div className="prod-mini-value">{formatCurrency(totalSaleValue)}</div>
                    <div className="prod-mini-footer">Venta total</div>
                </div>

                {/* Margen */}
                <div className={`prod-mini-card ${totalMargin >= 0 ? 'green' : 'red'}`}>
                    <div className="prod-mini-label"><Sparkles size={12} /> Margen</div>
                    <div className="prod-mini-value">{marginPct}%</div>
                    <div className="prod-mini-footer">{formatCurrency(totalMargin)}</div>
                </div>
            </div>

            {/* Top Selling Widget */}
            <div className="prod-aside-card desktop-only">
                <div className="prod-aside-header">
                    <h3 className="prod-aside-title">Top Productos</h3>
                    <div className="prod-aside-badge">Ventas</div>
                </div>
                {/* ... (resto del código del top products igual) */}
                {topProducts.length === 0 ? (
                    <div className="prod-empty-top">
                        <span style={{ fontSize: '1.5rem', marginBottom: '0.5rem', display: 'block' }}>📈</span>
                        <p>Sin ventas registradas</p>
                    </div>
                ) : (
                    <div className="prod-top-list">
                        {topProducts.map((p, idx) => (
                            <div className="prod-top-item" key={p.id}>
                                <div className="prod-top-item-info">
                                    <div className="prod-top-rank">{idx + 1}</div>
                                    <div className="prod-top-img">📦</div>
                                    <div>
                                        <div className="prod-top-name">{p.name || 'Producto'}</div>
                                        <div className="prod-top-sales">{p.quantity} {p.quantity === 1 ? 'unidad' : 'unidades'}</div>
                                    </div>
                                </div>
                                <div className="prod-top-revenue">{formatCurrency(p.revenue)}</div>
                            </div>
                        ))}
                    </div>
                )}
            </div>
        </aside>
    )
}
